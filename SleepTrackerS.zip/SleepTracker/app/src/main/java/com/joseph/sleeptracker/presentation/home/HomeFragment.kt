package com.joseph.sleeptracker.presentation.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.joseph.sleeptracker.R
import com.joseph.sleeptracker.presentation.MainActivity
import com.joseph.sleeptracker.presentation.add.AddFragment
import com.joseph.sleeptracker.presentation.home.adapter.SleepRecordAdapter

class HomeFragment : Fragment() {

    private lateinit var fab: FloatingActionButton
    private lateinit var recyclerView: RecyclerView
    private lateinit var recordAdapter: SleepRecordAdapter
    private lateinit var noRecord: TextView
    private lateinit var viewModel: ShareViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_record, container, false)
        fab = view.findViewById(R.id.add)
        recyclerView = view.findViewById(R.id.dailyTrackRecordRecyclerView)
        noRecord = view.findViewById(R.id.norecord)
        viewModel = (activity as MainActivity).shareViewModel
        initViews()
        initListeners()
        return view
    }

    private fun initViews() {

        viewModel.getAllRecords()
        recordAdapter = SleepRecordAdapter(mutableListOf())
        recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = recordAdapter
        }
        getRecords()
        viewModel.records.observe(viewLifecycleOwner){
            recordAdapter.sleepRecords = it
            if(it.isNullOrEmpty()){
                recyclerView.visibility=View.GONE
                noRecord.visibility = View.VISIBLE
            }else{
                recyclerView.visibility=View.VISIBLE
                noRecord.visibility = View.GONE
            }
        }
    }

    private fun initListeners() {
        fab.setOnClickListener {
            (activity as MainActivity).replaceFragment(AddFragment())
        }
    }

    private fun getRecords(){
        viewModel.getAllRecords()
        viewModel.records.observeForever {
            recordAdapter.notifyDataSetChanged()
        }
    }
}
package com.joseph.sleeptracker.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.joseph.sleeptracker.data.model.SleepRecord

@Dao
interface SleepDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(sleepRecord: SleepRecord)

    @Query("Select * from sleep_record")
    suspend fun getAllRecord(): List<SleepRecord>
}
package com.joseph.sleeptracker.domain

import com.joseph.sleeptracker.data.dao.SleepDao
import com.joseph.sleeptracker.data.model.SleepRecord

class RecordRepository(private val sleepDao: SleepDao) {

    suspend fun getRecords() = sleepDao.getAllRecord()

    suspend fun insertRecord(sleepRecord: SleepRecord) {
        sleepDao.insertRecord(sleepRecord)
    }
}
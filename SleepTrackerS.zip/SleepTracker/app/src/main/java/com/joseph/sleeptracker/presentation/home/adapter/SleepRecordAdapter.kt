package com.joseph.sleeptracker.presentation.home.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.joseph.sleeptracker.R
import com.joseph.sleeptracker.data.model.SleepRecord

class SleepRecordAdapter(var sleepRecords: List<SleepRecord>) :
    RecyclerView.Adapter<SleepRecordAdapter.SleepRecordViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SleepRecordViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.daily_track, parent, false)
        return SleepRecordViewHolder(view)
    }

    override fun onBindViewHolder(holder: SleepRecordViewHolder, position: Int) {
        val sleepRecord = sleepRecords[position]
        holder.dateTextView.text = sleepRecord.date
        holder.sleepTimeTextView.text = "Slept ${sleepRecord.hours} Hours"
        holder.moodTextView.text = getMoodFromValue(sleepRecord.mood)
    }

    override fun getItemCount(): Int {
        return sleepRecords.size
    }

    inner class SleepRecordViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dateTextView: TextView = itemView.findViewById(R.id.dateTextView)
        val sleepTimeTextView: TextView = itemView.findViewById(R.id.sleepTimeTextView)
        val moodTextView: TextView = itemView.findViewById(R.id.moodTextView)
    }

    private fun getMoodFromValue(value: Int): String {
        return when (value) {
            in 9..10 -> "Good Sleep"
            in 7..8 -> "Feeling Refreshed"
            in 5..6 -> "Neutral"
            in 3..4 -> "Feeling Tired"
            in 1..2 -> "Bad Dreams"
            else -> "Neutral"
        }
    }

}
